# Marker Gene Finder analysis bundle

Application version: 3.0.2

This archive contains marker results and the settings used to produce them. If present, `expression_summary.csv` contains the genes selected in the expression plots. `cluster_summary.csv` contains cluster cell counts and dataset percentages.

`provenance.json` records the execution environment and effective settings. `analysis_config.json` is the requested configuration, reusable with --config. Input hashes are optional; the expression matrix is not included.
